public class even1to20{ 
   public static void main(String[] args) { 
       for(int i = 1; i <= 20; i++) { 
           if(i % 2 == 0) { 
               System.out.print(i + " "); 
           } 
       } 
   } 
}


public class even1to20{ 
   public static void main(String[] args) { 
       for(int i = 1; i <= 20; i++) { 
           if(i % 2 == 0) { 
               System.out.print(i + " "); 
           } 
       } 
   } 
}


public class even1to20{ 
   public static void main(String[] args) { 
       for(int i = 1; i <= 20; i++) { 
           if(i % 2 == 0) { 
               System.out.print(i + " "); 
           } 
       } 
   } 
}